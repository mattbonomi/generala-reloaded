/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Users, Plus, Trash2, Trophy, X, ChevronLeft, PenLine, Mic, MicOff, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

declare global {
  interface Window {
    SpeechRecognition: unknown;
    webkitSpeechRecognition: unknown;
  }
}

type Category =
  | "1"
  | "2"
  | "3"
  | "4"
  | "5"
  | "6"
  | "escalera"
  | "full"
  | "poker"
  | "generala"
  | "dobleGenerala";

type Player = {
  id: string;
  name: string;
  scores: Partial<Record<Category, number>>;
};

const CATEGORY_NAMES: Record<Category, string> = {
  "1": "1",
  "2": "2",
  "3": "3",
  "4": "4",
  "5": "5",
  "6": "6",
  escalera: "Escalera",
  full: "Full",
  poker: "Póker",
  generala: "Generala",
  dobleGenerala: "Doble Gen.",
};

const VALID_SCORES: Record<Category, number[]> = {
  "1": [0, 1, 2, 3, 4, 5],
  "2": [0, 2, 4, 6, 8, 10],
  "3": [0, 3, 6, 9, 12, 15],
  "4": [0, 4, 8, 12, 16, 20],
  "5": [0, 5, 10, 15, 20, 25],
  "6": [0, 6, 12, 18, 24, 30],
  escalera: [0, 20, 25],
  full: [0, 30, 35],
  poker: [0, 40, 45],
  generala: [0, 50, 55],
  dobleGenerala: [0, 100, 105],
};

// Map of Spanish number words to digits
const numberWords: Record<string, number> = {
  "cero": 0, "uno": 1, "un": 1, "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5,
  "seis": 6, "siete": 7, "ocho": 8, "nueve": 9, "diez": 10
};

export default function GeneralaScorecard() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [newPlayerName, setNewPlayerName] = useState("");
  const [gameStarted, setGameStarted] = useState(false);
  const [currentPlayerIndex, setCurrentPlayerIndex] = useState(0);
  const [selectedCell, setSelectedCell] = useState<{
    playerId: string;
    category: Category;
  } | null>(null);

  // Voice recognition state
  const [isListening, setIsListening] = useState(false);
  const [isProcessingVoice, setIsProcessingVoice] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 4000);
  };

  const addPlayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlayerName.trim()) return;
    
    // Use a combination of timestamp and random string to guarantee uniqueness
    const newId = `player-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

    setPlayers((prev) => [
      ...prev,
      {
        id: newId,
        name: newPlayerName.trim(),
        scores: {},
      },
    ]);
    setNewPlayerName("");
  };

  const removePlayer = (id: string) => {
    setPlayers((prev) => prev.filter((p) => p.id !== id));
  };

  const startGame = () => {
    if (players.length > 0) {
      setCurrentPlayerIndex(0);
      setGameStarted(true);
    }
  };

  const resetGame = () => {
    if (confirm("¿Estás seguro de que quieres reiniciar la partida? Todos los puntajes se perderán.")) {
      setPlayers(players.map((p) => ({ ...p, scores: {} })));
      setCurrentPlayerIndex(0);
    }
  };

  const backToSetup = () => {
    if (confirm("¿Volver al inicio? Los puntajes actuales se perderán.")) {
      setGameStarted(false);
      setPlayers(players.map((p) => ({ ...p, scores: {} })));
      setCurrentPlayerIndex(0);
    }
  };

  const setScore = (playerId: string, category: Category, score: number | null) => {
    setPlayers((prev) =>
      prev.map((p) => {
        if (p.id === playerId) {
          const newScores = { ...p.scores };
          if (score === null) {
            delete newScores[category];
          } else {
            newScores[category] = score;
          }
          return { ...p, scores: newScores };
        }
        return p;
      })
    );
    setSelectedCell(null);

    // Advance turn if a score was added for the current player
    if (score !== null && players[currentPlayerIndex]?.id === playerId) {
      setCurrentPlayerIndex((prev) => (prev + 1) % players.length);
    }
  };

  const getTotalScore = (player: Player) => {
    return Object.values(player.scores).reduce((sum, score) => sum + (score || 0), 0);
  };

  const getLeaderId = () => {
    if (players.length === 0) return null;
    const totals = players.map((p) => ({ id: p.id, total: getTotalScore(p) }));
    const maxTotal = Math.max(...totals.map((t) => t.total));
    if (maxTotal === 0) return null;
    const leaders = totals.filter((t) => t.total === maxTotal);
    return leaders.length === 1 ? leaders[0].id : null;
  };

  const processVoiceCommand = async (transcript: string) => {
    setIsProcessingVoice(true);
    try {
      // Parse common voice commands manually
      const text = transcript.toLowerCase().trim();
      
      // Try to identify category and score from voice
      let category: Category | null = null;
      let score: number | null = null;
      let targetPlayer = players[currentPlayerIndex];

      // Check for player names in transcript
      for (const player of players) {
        if (text.includes(player.name.toLowerCase())) {
          targetPlayer = player;
          break;
        }
      }

      // Check for "tachar", "cero" or "raya" (cross out) first
      if (text.includes("tachar") || text.includes("raya")) {
        score = 0;
      }

      // Check for categories - order matters! Check doble generala first
      if ((text.includes("doble") && (text.includes("generala") || text.includes("general"))) || text.includes("doble generala")) {
        category = "dobleGenerala";
        if (score === null) {
          // Check for "servida", "servido", "vida" (common mishearing)
          score = (text.includes("servida") || text.includes("servido") || text.includes("vida")) ? 105 : 100;
        }
      } else if (text.includes("escalera")) {
        category = "escalera";
        if (score === null) {
          score = (text.includes("servida") || text.includes("servido") || text.includes("vida")) ? 25 : 20;
        }
      } else if (text.includes("full")) {
        category = "full";
        if (score === null) {
          score = (text.includes("servida") || text.includes("servido") || text.includes("vida")) ? 35 : 30;
        }
      } else if (text.includes("poker")) {
        category = "poker";
        if (score === null) {
          score = (text.includes("servida") || text.includes("servido") || text.includes("vida")) ? 45 : 40;
        }
      } else if (text.includes("generala") || text.includes("general")) {
        // "general" is a common mishearing of "generala"
        category = "generala";
        if (score === null) {
          score = (text.includes("servida") || text.includes("servido") || text.includes("vida")) ? 55 : 50;
        }
      } else {
        // Check for number categories (1-6)
        // Pattern: "[number] al [number]" or "[number] [number]s"
        // Examples: "tres al cinco", "dos al cuatro", "tres cincos"
        
        let diceCount = 0;
        let categoryNumber = 0;

        // Try to match patterns like "tres al cinco" or "dos al tres"
        // Look for number words specifically in the pattern "[number] al [number]"
        const alPattern = /(cero|uno|un|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez)\s+al\s+(cero|uno|un|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez)/;
        const alMatch = text.match(alPattern);
        
        if (alMatch) {
          const countWord = alMatch[1];
          const categoryWord = alMatch[2];
          diceCount = numberWords[countWord] || 0;
          categoryNumber = numberWords[categoryWord] || 0;
          // Make sure we have valid numbers
          if (diceCount === 0 || categoryNumber === 0 || categoryNumber > 6) {
            diceCount = 0;
            categoryNumber = 0;
          }
        } else {
          // Find all number words in order of appearance
          const foundNumbers: Array<{word: string, value: number, index: number}> = [];
          
          for (const [word, value] of Object.entries(numberWords)) {
            if (value > 0 && value <= 6) {
              const index = text.indexOf(word);
              if (index !== -1) {
                foundNumbers.push({word, value, index});
              }
            }
          }
          
          // Sort by order of appearance in the text
          foundNumbers.sort((a, b) => a.index - b.index);
          
          // If we found at least 2 numbers, use the first as count and second as category
          if (foundNumbers.length >= 2) {
            diceCount = foundNumbers[0].value;
            categoryNumber = foundNumbers[1].value;
          } else if (foundNumbers.length === 1) {
            // If only one number found, assume it's the category
            categoryNumber = foundNumbers[0].value;
            diceCount = 1; // Default to 1 die
          }
        }

        // If we found a valid pattern
        if (diceCount > 0 && categoryNumber > 0 && categoryNumber <= 6) {
          category = categoryNumber.toString() as Category;
          score = diceCount * categoryNumber;
        } else {
          // Fallback: check for number categories (1-6) by digit
          for (let i = 1; i <= 6; i++) {
            if (text.includes(i.toString())) {
              category = i.toString() as Category;
              // Count how many times the number appears (number of dice)
              const count = (text.match(new RegExp(i.toString(), 'g')) || []).length;
              if (count > 0) {
                score = count * i;
              }
              break;
            }
          }
        }
      }

      if (category && score !== null && targetPlayer) {
        setScore(targetPlayer.id, category, score);
        const catName = CATEGORY_NAMES[category] || category;
        showToast(`Anotado: ${score} puntos en ${catName} para ${targetPlayer.name}`);
      } else {
        showToast("No se pudo entender a qué categoría te referías.");
      }

    } catch (error) {
      console.error(error);
      showToast("Hubo un error al procesar el comando de voz.");
    } finally {
      setIsProcessingVoice(false);
    }
  };

  const startListening = () => {
    const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognitionAPI) {
      alert("Tu navegador no soporta reconocimiento de voz.");
      return;
    }

    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }

    const recognition = new (SpeechRecognitionAPI as any)();
    recognitionRef.current = recognition;
    recognition.lang = 'es-AR';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      processVoiceCommand(transcript);
    };

    recognition.onerror = (event: any) => {
      console.error("Speech recognition error", event.error);
      if (event.error === 'not-allowed') {
        showToast("Permiso de micrófono denegado. Por favor, permítelo en tu navegador.");
      } else if (event.error !== 'aborted') {
        showToast("Error con el micrófono: " + event.error);
      }
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };

  const leaderId = getLeaderId();

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-zinc-950 text-zinc-50 p-4 md:p-8 font-sans flex items-center justify-center">
        <div className="w-full max-w-md bg-zinc-900 rounded-3xl p-8 border border-zinc-800 shadow-2xl">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emerald-500/10 text-emerald-400 mb-4">
              <PenLine className="w-8 h-8" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-white mb-2">Anotador</h1>
            <p className="text-zinc-400">Agrega a los jugadores para comenzar</p>
          </div>

          <form onSubmit={addPlayer} className="flex gap-2 mb-8">
            <input
              type="text"
              value={newPlayerName}
              onChange={(e) => setNewPlayerName(e.target.value)}
              placeholder="Nombre del jugador..."
              className="flex-1 bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
              maxLength={15}
            />
            <button
              type="submit"
              disabled={!newPlayerName.trim()}
              className="bg-emerald-500 text-zinc-950 px-4 py-3 rounded-xl font-bold hover:bg-emerald-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Plus className="w-5 h-5" />
            </button>
          </form>

          <div className="space-y-2 mb-8 max-h-[40vh] overflow-y-auto pr-2 custom-scrollbar">
            <AnimatePresence>
              {players.map((player) => (
                <motion.div
                  key={player.id}
                  initial={{ opacity: 0, scale: 0.95, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, x: -10 }}
                  className="flex items-center justify-between bg-zinc-950/50 border border-zinc-800 rounded-xl p-3"
                >
                  <span className="font-medium text-zinc-200">{player.name}</span>
                  <button
                    onClick={() => removePlayer(player.id)}
                    className="text-zinc-500 hover:text-red-400 p-1 rounded-md hover:bg-red-400/10 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </motion.div>
              ))}
              {players.length === 0 && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-8 text-zinc-500 text-sm"
                >
                  No hay jugadores todavía.
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <button
            onClick={startGame}
            disabled={players.length === 0}
            className="w-full bg-emerald-500 text-zinc-950 py-4 rounded-xl font-bold text-lg hover:bg-emerald-400 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(16,185,129,0.2)] disabled:shadow-none"
          >
            <Users className="w-5 h-5" />
            Comenzar Partida
          </button>
        </div>
      </div>
    );
  }

  const selectedPlayer = players.find((p) => p.id === selectedCell?.playerId);
  const selectedCategoryName = selectedCell ? CATEGORY_NAMES[selectedCell.category] : "";
  const isNumberCategory = selectedCell ? ["1", "2", "3", "4", "5", "6"].includes(selectedCell.category) : false;

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-50 font-sans flex flex-col relative">
      {/* Header */}
      <header className="bg-zinc-900 border-b border-zinc-800 p-4 sticky top-0 z-20 shadow-md">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={backToSetup}
              className="text-zinc-400 hover:text-white transition-colors p-2 -ml-2 rounded-lg hover:bg-zinc-800"
              title="Volver al inicio"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <h1 className="text-xl font-bold tracking-tight text-emerald-400 flex items-center gap-2">
              <PenLine className="w-5 h-5" />
              Anotador
            </h1>
          </div>
          <button
            onClick={resetGame}
            className="text-sm font-medium text-zinc-400 hover:text-white px-3 py-1.5 rounded-md hover:bg-zinc-800 transition-colors"
          >
            Reiniciar
          </button>
        </div>
      </header>

      {/* Score Grid */}
      <main className="flex-1 p-4 md:p-8">
        <div className="max-w-6xl mx-auto">
          {/* Added overflow-x-auto to the wrapper to ensure horizontal scrolling works for many players */}
          <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl overflow-hidden">
            <div className="overflow-x-auto custom-scrollbar">
              <table className="w-full border-collapse text-left min-w-max">
                <thead>
                  <tr>
                    <th className="sticky left-0 z-10 bg-zinc-900 border-b border-r border-zinc-800 p-4 w-32 md:w-48 shadow-[4px_0_8px_-4px_rgba(0,0,0,0.5)]">
                      <span className="text-xs uppercase tracking-wider text-zinc-500 font-semibold">Categoría</span>
                    </th>
                    {players.map((player, index) => (
                      <th
                        key={player.id}
                        onClick={() => setCurrentPlayerIndex(index)}
                        className={cn(
                          "border-b border-zinc-800 p-4 min-w-[100px] md:min-w-[140px] text-center transition-colors cursor-pointer hover:bg-zinc-800/50",
                          currentPlayerIndex === index ? "bg-zinc-800/80" : leaderId === player.id ? "bg-emerald-500/5" : ""
                        )}
                      >
                        <div className="flex flex-col items-center gap-1">
                          {currentPlayerIndex === index && (
                            <span className="text-[10px] uppercase tracking-wider font-bold bg-emerald-500 text-zinc-950 px-2 py-0.5 rounded-full mb-1 shadow-[0_0_10px_rgba(16,185,129,0.3)]">
                              Turno
                            </span>
                          )}
                          {leaderId === player.id && currentPlayerIndex !== index && (
                            <Trophy className="w-4 h-4 text-emerald-400 mb-1" />
                          )}
                          <span className={cn(
                            "font-bold truncate w-full",
                            currentPlayerIndex === index ? "text-white" : leaderId === player.id ? "text-emerald-400" : "text-zinc-400"
                          )}>
                            {player.name}
                          </span>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(Object.keys(CATEGORY_NAMES) as Category[]).map((category) => (
                    <tr key={category} className="hover:bg-zinc-800/30 transition-colors">
                      <td className="sticky left-0 z-10 bg-zinc-900 border-b border-r border-zinc-800 p-4 shadow-[4px_0_8px_-4px_rgba(0,0,0,0.5)]">
                        <span className="font-medium text-zinc-300">{CATEGORY_NAMES[category]}</span>
                      </td>
                      {players.map((player, index) => {
                        const score = player.scores[category];
                        const isScored = score !== undefined;
                        const isScratched = score === 0;

                        return (
                          <td
                            key={`${player.id}-${category}`}
                            className={cn(
                              "border-b border-zinc-800 p-2 text-center transition-colors",
                              currentPlayerIndex === index ? "bg-zinc-800/20" : leaderId === player.id ? "bg-emerald-500/5" : ""
                            )}
                          >
                            <button
                              onClick={() => setSelectedCell({ playerId: player.id, category })}
                              className={cn(
                                "w-full h-12 rounded-lg flex items-center justify-center text-lg font-bold transition-all",
                                !isScored && "text-zinc-700 hover:bg-zinc-800 hover:text-zinc-400",
                                isScored && !isScratched && "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20",
                                isScratched && "bg-red-500/10 text-red-400 border border-red-500/20 line-through decoration-2"
                              )}
                            >
                              {isScored ? (isScratched ? "0" : score) : "-"}
                            </button>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="bg-zinc-950/50">
                    <td className="sticky left-0 z-10 bg-zinc-950 border-r border-zinc-800 p-4 shadow-[4px_0_8px_-4px_rgba(0,0,0,0.5)]">
                      <span className="font-bold text-white uppercase tracking-wider">Total</span>
                    </td>
                    {players.map((player, index) => (
                      <td
                        key={`total-${player.id}`}
                        className={cn(
                          "p-4 text-center transition-colors",
                          currentPlayerIndex === index ? "bg-zinc-800/40" : leaderId === player.id ? "bg-emerald-500/5" : ""
                        )}
                      >
                        <span className={cn(
                          "text-2xl font-bold font-mono",
                          leaderId === player.id ? "text-emerald-400" : "text-white"
                        )}>
                          {getTotalScore(player)}
                        </span>
                      </td>
                    ))}
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </main>

      {/* Voice Command FAB */}
      <div className="fixed bottom-6 right-6 z-30 flex flex-col items-end gap-3">
        <AnimatePresence>
          {toast && (
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-zinc-800 text-white px-4 py-3 rounded-xl shadow-2xl border border-zinc-700 text-sm font-medium max-w-[250px] text-center"
            >
              {toast}
            </motion.div>
          )}
        </AnimatePresence>
        <button
          onClick={isListening ? stopListening : startListening}
          disabled={isProcessingVoice}
          className={cn(
            "w-16 h-16 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(0,0,0,0.5)] transition-all",
            isListening ? "bg-red-500 text-white animate-pulse" :
            isProcessingVoice ? "bg-zinc-700 text-zinc-400" :
            "bg-emerald-500 text-zinc-950 hover:bg-emerald-400 hover:scale-105"
          )}
          title="Anotar por voz"
        >
          {isProcessingVoice ? <Loader2 className="w-7 h-7 animate-spin" /> :
           isListening ? <MicOff className="w-7 h-7" /> :
           <Mic className="w-7 h-7" />}
        </button>
      </div>

      {/* Input Modal */}
      <AnimatePresence>
        {selectedCell && selectedPlayer && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedCell(null)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-sm bg-zinc-900 border border-zinc-800 rounded-3xl p-6 z-50 shadow-2xl"
            >
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h3 className="text-zinc-400 text-sm font-medium mb-1">{selectedPlayer.name}</h3>
                  <h2 className="text-2xl font-bold text-white">{selectedCategoryName}</h2>
                </div>
                <button
                  onClick={() => setSelectedCell(null)}
                  className="text-zinc-500 hover:text-white p-2 bg-zinc-800/50 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {isNumberCategory ? (
                <div className="grid grid-cols-3 gap-3 mb-6">
                  {[0, 1, 2, 3, 4, 5].map((count) => {
                    const scoreValue = count * parseInt(selectedCell.category);
                    return (
                      <button
                        key={count}
                        onClick={() => setScore(selectedCell.playerId, selectedCell.category, scoreValue)}
                        className={cn(
                          "py-3 rounded-xl font-bold transition-all flex flex-col items-center justify-center gap-1",
                          count === 0
                            ? "bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20"
                            : "bg-zinc-800 text-white hover:bg-emerald-500 hover:text-zinc-950 border border-zinc-700 hover:border-emerald-500"
                        )}
                      >
                        <span className="text-lg">{count === 0 ? "Tachar" : `${count} dado${count !== 1 ? 's' : ''}`}</span>
                        {count > 0 && <span className="text-xs opacity-70 font-normal">({scoreValue} pts)</span>}
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-3 mb-6">
                  {VALID_SCORES[selectedCell.category].map((scoreValue) => {
                    const isZero = scoreValue === 0;
                    return (
                      <button
                        key={scoreValue}
                        onClick={() => setScore(selectedCell.playerId, selectedCell.category, scoreValue)}
                        className={cn(
                          "py-4 rounded-xl font-bold text-xl transition-all",
                          isZero
                            ? "bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20"
                            : "bg-zinc-800 text-white hover:bg-emerald-500 hover:text-zinc-950 border border-zinc-700 hover:border-emerald-500"
                        )}
                      >
                        {isZero ? "Tachar" : scoreValue}
                      </button>
                    );
                  })}
                </div>
              )}

              {selectedPlayer.scores[selectedCell.category] !== undefined && (
                <button
                  onClick={() => setScore(selectedCell.playerId, selectedCell.category, null)}
                  className="w-full py-3 rounded-xl font-medium text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
                >
                  Borrar anotación
                </button>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <style dangerouslySetInnerHTML={{__html: `
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(24, 24, 27, 0.5);
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(63, 63, 70, 0.8);
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(82, 82, 91, 1);
        }
      `}} />
    </div>
  );
}
